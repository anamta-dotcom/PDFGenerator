package pdfgenerator.pdf.Service;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.itextpdf.text.pdf.PdfWriter.getInstance;

@Service
public class pdfService {
    public boolean uploadFile(MultipartFile file, String text) throws IOException, DocumentException {
        boolean f = false;
        try {
            String fileName = file.getOriginalFilename();
            String pdfFileName = fileName.substring(0, fileName.lastIndexOf(".")) + ".pdf";
            Document doc = new Document(PageSize.A4, 20, 20, 20, 20);
            PdfWriter instance = getInstance(doc, new FileOutputStream(pdfFileName));
            doc.open();
            doc.newPage();
            Image image = Image.getInstance(file.getBytes());
            float height = image.getHeight();
            float width = image.getWidth();
            int percent = getPercent(height, width);
            image.setAlignment(Image.MIDDLE);
            image.scalePercent(percent);
            doc.add(image);
            doc.add(new Paragraph(text));
            doc.close();
            new File(pdfFileName);
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return f;
    }

    private static int getPercent(float height, float weight) {
        float percent = 0.0F;
        if (height > weight) {
            percent = PageSize.A4.getHeight() / height * 100;
        } else {
            percent = PageSize.A4.getWidth() / weight * 100;
        }
        return Math.round(percent);
    }
}

