package pdfgenerator.pdf.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import pdfgenerator.pdf.Service.pdfService;


@RestController
    public class pdfController {
    @Autowired
    private pdfService pdfHandleImage;

    @PostMapping("/upload_file")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file, @RequestParam String text) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("No file is submitted...");
            }
            boolean f = pdfHandleImage.uploadFile(file,text);
            if (f) {
                return ResponseEntity.ok("File successfully submitted...");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong, Try again");
    }
    }



